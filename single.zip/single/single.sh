#!/bin/sh
#$ -q all.q@fs16
#$ -cwd
#$ -V
#$ -pe make 30
export MAX_PROCESS=30

 R --vanilla -q  --file=/home/iurii/REPEAT_SIM/1000_Cells/1000_Cells_Single/CancerProgress_Final_Version.R > R_out.txt


