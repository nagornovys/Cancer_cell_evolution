
rm R_out.txt cellout.txt geneout.txt last_steps.txt log.txt test*.sh.e*  test*.sh.o*    

clear


