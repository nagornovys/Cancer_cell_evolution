
rm R_out.txt cellout.txt geneout.txt last_steps.txt log.txt sub.sh.*  

clear


