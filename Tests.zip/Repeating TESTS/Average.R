
data_out <- read.csv("cellout.txt", sep="\t")

data_out <- read.csv("TEST_3_Apoptosis/cellout.txt", sep="\t")

View(data_out)


plot(data_out$Time,data_out$N,type = "p",cex = 0.2)


n <- which(data_out$Time == 2)
data_ave <- matrix(data = 0, ncol = 2,nrow = 70)


for (k in 2:70 ) {
  
  data_ave[k,1] = k
  n <- which(data_out$Time == k)
  data_ave[k,2] = sum(data_out$N[n])/100
}


plot(data_out$Time,data_out$N,type = "p",cex = 0.15, xlab = "Generation number", ylab = "Number of cells",ylim = c(0,1700))
lines(data_ave[2:70,1],data_ave[2:70,2],type = "l",lwd = 3, col = "red", add = TRUE)

legend("topleft", c("100 simulations", "average numer of cells"), bty = "n", col = c("black","red"),lty = c(NA,1),pch = c(1,NA),pt.cex = 0.15,lwd = c(NA,2.4), horiz = TRUE)


library(MASS)

df <- data.frame(x=data_out$Time,y=data_out$N)

# colors
library(RColorBrewer)
rf <- colorRampPalette(rev(brewer.pal(11,'Spectral')))
r <- rf(40)

# Adjust binning (interpolate - can be computationally intensive for large datasets)
k <- kde2d(df$x, df$y, n=c(300,300))
k$z <- k$z / max(k$z)

breaks <- 1:(length(r)+1)
breaks <- breaks / length(r)
image(k, col=r, breaks = breaks, xlab = "Generation number", ylab = "Number of cells",ylim = c(0,1500))

lines(data_ave[2:70,1],data_ave[2:70,2],type = "l",lwd = 2.4, col = "#FF3300")

levels <- c(min(breaks),0.05,0.1,0.2,0.4,0.6,0.8)
contour(k, levels = levels, lty = 1 , lwd=0.9, col= "#00EE99", drawlabels = FALSE, add = TRUE)



image.default(k, col=r, breaks = breaks, xlab = "Generation number", ylab = "Number of cells",ylim = c(0,1800),xlim = c(1,70),legend=TRUE)

# For each time step
for (kk in 2:69) {

numb <- which( xor(df$x==kk,df$x==(kk+1)) )
k <- kde2d(df$x[numb], df$y[numb], n=c(2,100))
k$z <- k$z / max(k$z)

breaks <- 1:(length(r)+1)
breaks <- breaks / length(r)
image(k, col=r, breaks = breaks, xlab = "Generation number", ylab = "Number of cells",ylim = c(0,1800),xlim = c(1,70),add = TRUE)

}



lines(data_ave[2:70,1],data_ave[2:70,2],type = "l",lty = 1, lwd = 5, col = "#FF00FF")



legend("top", c("average numer of cells",""), bty = "n", col = c("#FF00FF",NA),lty = c(1,NA),pch = c(NA,NA),pt.cex = 0.15,lwd = c(4,NA), horiz = TRUE)



