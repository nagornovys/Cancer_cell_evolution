#!/bin/sh
#$ -q all.q@fs14
#$ -cwd
#$ -V
#$ -pe make 30
export MAX_PROCESS=30

 R --vanilla -q  --file=/home/iurii/REPEAT_SIM/Weights/CancerProgress_Final_Version.R > R_out.txt


