# The code to analize the results of simulation

# readline(prompt="Press [enter] to continue")

# Analising of results:
data_out <- read.csv(celloutfile, sep="\t")
data_out[is.na(data_out)] <- ""
# make a readible names
names(data_out)[5] <-  "c"
names(data_out)[6] <-  "d"
names(data_out)[7] <-  "i"
names(data_out)[8] <-  "im"
names(data_out)[9] <-  "a"
names(data_out)[10] <- "k"
names(data_out)[11] <- "E"
names(data_out)[13] <- "Nmax"
names(data_out)

# average data
data_avg <- data_out[which(data_out$AvgOrIndx == "avg"),]

# data without averaging - flow data
data_flow <- data_out[which(!data_out$AvgOrIndx == "avg"),]

# the data of the last time step 
time_max <- max(data_flow$Time)
data_last <- data_flow[which(data_flow$Time == time_max),]


# let draw graphics 
# Numbers of Metastasis and normal cells
g_range_y <- range(0, data_avg$N,data_flow$M)
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))
plot(data_avg$Time,data_avg$M,type = "l",cex.lab=1.4,lwd=2,xlab = "Generation number",
     ylab = "Number of cells",ylim=g_range_y,xlim = g_range_x,col = "red")
lines(data_avg$Time,data_avg$N,type = "l",col = "blue",lwd=2)
par(xpd=TRUE)
legend(g_range_x[1]/2+g_range_x[2]/2.5, 1.3*g_range_y[2], c("Normal","Metastasis"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1)

# Average values of probabilities
g_range_y <- range(0, data_avg[6:10])
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))

plot(data_avg$Time,data_avg$d,type = "l", ylim=g_range_y,xlim = g_range_x,cex.lab=1.4,
     xlab = "Generation number",ylab = "The average probabilities",col = "red",lwd = 2)

lines(data_avg$Time,data_avg$i,type = "l",col = "blue",lwd = 2)
lines(data_avg$Time,data_avg$im,type = "l",col = "green",lwd = 2)
lines(data_avg$Time,data_avg$a,type = "l",col = "orange",lwd = 2)
lines(data_avg$Time,data_avg$k,type = "l",col = "black",lwd = 2)
par(xpd=TRUE)
legend(g_range_x[2]-1.4, 0.7*(g_range_y[1]+g_range_y[2]), c("d","i","im","a","k"), cex=1,col=c("red","blue","green","orange","black"), lty = 1:1,lwd = 2)


# The averaged values of Hallmarks 
g_range_y <- range(0, data_avg[15:19])
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))

plot(data_avg$Time,data_avg$Hd,type = "l", ylim=g_range_y,xlim = g_range_x,cex.lab=1.4,
     xlab = "Generation number",ylab = "The averaged Hallmarks values",col = "red",lwd = 2)

lines(data_avg$Time,data_avg$Hi,type = "l",col = "blue",lwd = 2)
lines(data_avg$Time,data_avg$Him,type = "l",col = "green",lwd = 2)
lines(data_avg$Time,data_avg$Ha,type = "l",col = "orange",lwd = 2)
lines(data_avg$Time,data_avg$Hb,type = "l",col = "black",lwd = 2)
par(xpd=TRUE)
legend(g_range_x[2]-1.6, 0.7*(g_range_y[1]+g_range_y[2]), c("Hd","Hi","Him","Ha","Hb"), cex=1,col=c("red","blue","green","orange","black"), lty = 1:1,lwd = 2)

# The histogram of parents-children relations for last generation
parents <- data_flow$ID[data_flow$Time == 1]
parents <- c(as.character(parents))
children_Time <- data_flow$Time[data_flow$Time > 1]
children_ID <- data_flow$ID[data_flow$Time > 1]
children_ParentID <- data_flow$ParentID[data_flow$Time > 1]

children_Time <- as.character(children_Time)
children_ID <- as.character(children_ID)
children_ParentID <- as.character(children_ParentID)


children <- data.frame(cbind(children_Time,children_ID,children_ParentID))
sapply(children, class)

l<-length(children$children_Time)
p<-length(parents)
# for (t in 2:time_max) {
for (i in 1:l) {
  
  a <- as.character(children$children_ParentID[i])
  b <- as.character(children$children_ID[i])
  
  if (!a=="0") {
    iw<-which(children$children_ParentID==b)  
    children$children_ParentID[iw] <- a
    
    print(i)  
    print(children$children_ParentID[i])
    print(c(a,b))
    print(iw)  
    
  }
}


# The history of cells - the time evolution of parents-children relations
sum_children <- matrix(data = 0,nrow = time_max, ncol = length(parents))
sum_children[1,] <- 1

for (j in 2:time_max) {
  for (i in 1:p) {
    
    a <- as.character(parents[i])
    iw<-which(children$children_ParentID==a & children$children_Time==as.character(j))  
    sum_children[j,i] <- length(iw)
    
    iw <- which(children$children_Time==as.character(j) & children$children_ID==a)
    if (!length(iw)==0) {
      sum_children[j,i] <- sum_children[j,i] +1
    }
    
  }
  
}


# To draw the results of statistics
g_range_y <- range(0, max(sum_children)+1)
g_range_x <- range(1,length(sum_children[,1]))

plot(data_avg$Time,sum_children[,1],type = "l", ylim=g_range_y,xlim = g_range_x,cex.lab=1.4,
     xlab = "Generation number",ylab = "Children's number",col = "red",lwd = 2)

par(xpd=TRUE)

for (i in 1:p) {
  r <- runif(1)
  g <- runif(1)
  b <- runif(1)
  lines(data_avg$Time,sum_children[,i],type = "l",col = rgb(r,g,b),lwd = 2,lt=i)
  #  legend(g_range_x[1], 50+(p-i)/p*(g_range_y[1]+g_range_y[2]), parents[i], cex=1,col=rgb(r,g,b), lty = i,lwd = 2)
}


