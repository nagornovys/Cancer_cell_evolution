# The code to analize the results of simulation

# readline(prompt="Press [enter] to continue")

# Analising of results:
data_out <- read.csv(celloutfile, sep="\t")
data_out[is.na(data_out)] <- ""
# make a readible names
names(data_out)[5] <-  "c"
names(data_out)[6] <-  "d"
names(data_out)[7] <-  "i"
names(data_out)[8] <-  "im"
names(data_out)[9] <-  "a"
names(data_out)[10] <- "k"
names(data_out)[11] <- "E"
names(data_out)[13] <- "Nmax"
names(data_out)

# average data
data_avg <- data_out[which(data_out$AvgOrIndx == "avg"),]

# data without averaging - flow data
data_flow <- data_out[which(!data_out$AvgOrIndx == "avg"),]

# the data of the last time step 
time_max <- max(data_flow$Time)
data_last <- data_flow[which(data_flow$Time == time_max),]


# let draw graphics 
# Numbers of Metastasis and normal cells
g_range_y <- range(0, data_avg$N,data_flow$M)
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))
plot(data_avg$Time,data_avg$M,type = "l",cex.lab=1.4,lwd=2,xlab = "Generation number",
     ylab = "Number of cells",ylim=g_range_y,xlim = g_range_x,col = "red")
lines(data_avg$Time,data_avg$N,type = "l",col = "blue",lwd=2)
par(xpd=TRUE)
legend(g_range_x[1]/2+g_range_x[2]/2.5, 1.3*g_range_y[2], c("Normal","Metastasis"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1)

# Average values of probabilities
g_range_y <- range(0, data_avg[6:10])
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))

plot(data_avg$Time,data_avg$d,type = "l", ylim=g_range_y,xlim = g_range_x,cex.lab=1.4,
     xlab = "Generation number",ylab = "The average probabilities",col = "red",lwd = 2)

lines(data_avg$Time,data_avg$i,type = "l",col = "blue",lwd = 2)
lines(data_avg$Time,data_avg$im,type = "l",col = "green",lwd = 2)
lines(data_avg$Time,data_avg$a,type = "l",col = "orange",lwd = 2)
lines(data_avg$Time,data_avg$k,type = "l",col = "black",lwd = 2)
par(xpd=TRUE)
legend(g_range_x[2]-1.4, 0.7*(g_range_y[1]+g_range_y[2]), c("d","i","im","a","k"), cex=1,col=c("red","blue","green","orange","black"), lty = 1:1,lwd = 2)


# The averaged values of Hallmarks 
g_range_y <- range(0, data_avg[15:19])
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))

plot(data_avg$Time,data_avg$Hd,type = "l", ylim=g_range_y,xlim = g_range_x,cex.lab=1.4,
     xlab = "Generation number",ylab = "The averaged Hallmarks values",col = "red",lwd = 2)

lines(data_avg$Time,data_avg$Hi,type = "l",col = "blue",lwd = 2)
lines(data_avg$Time,data_avg$Him,type = "l",col = "green",lwd = 2)
lines(data_avg$Time,data_avg$Ha,type = "l",col = "orange",lwd = 2)
lines(data_avg$Time,data_avg$Hb,type = "l",col = "black",lwd = 2)
par(xpd=TRUE)
legend(g_range_x[2]-1.6, 0.7*(g_range_y[1]+g_range_y[2]), c("Hd","Hi","Him","Ha","Hb"), cex=1,col=c("red","blue","green","orange","black"), lty = 1:1,lwd = 2)

