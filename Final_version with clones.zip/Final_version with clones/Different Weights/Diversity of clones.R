# Diversity of clones



# The function is in the Analize.R file 
analize_data(celloutfile)

# time_max - number of time steps 


clones <- matrix(nrow = length(data_flow$Time), ncol = 4)
clones[,1] <- as.integer(as.character(data_flow$Time))
clones[,2] <- as.integer(as.character(data_flow$Clone.number))
clones[,3] <- as.integer(as.character(data_flow$Passengers.Clone.number))
clones[,4] <- as.integer(as.character(data_flow$Mix.Clone.number))
#ord_cl <- 10^(length(onco$name))

#for (i in 1:length(clones[,1])) {
#clones[i,4] <- as.numeric(as.character(data_flow$Clone.number[i])) * ord_cl  + as.numeric(as.character(data_flow$Passengers.Clone.number[i])) 
#}


diversity <- matrix(nrow = time_max, ncol = 2)

for (i in 1:time_max) {
diversity[i,1] <- length(table(clones[which(clones[,1]==i),2]))
# diversity[i,2] <- diversity[i,1] / (data_avg$N[i] + data_avg$M[i])
diversity[i,2] <- length(table(clones[which(clones[,1]==i),4]))
}  

g_range_y <- range(0, max(diversity[,2],diversity[,1]))
plot(1:time_max,diversity[,1],type = "l",col = "blue", lwd=2, ylim=g_range_y, xlab = "Time step", ylab = "Diversity or Number of clones") # number of clones - diversity
lines(1:time_max,diversity[,2],type = "l",col = "red", lwd=2)
legend(1, 1.2*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1,horiz = TRUE)

# plot(1:time_max,diversity[,2],type = "l",col = "red", lwd=2,xlab = "Time step", ylab = "Normilized diversity") # normalized diversity



# Number of cells in each clone

x <- table(clones[,2]) # names of all clones - "numeric" name of clones

total_clones <- length(names(x)) # number of all clones

 evolution_clones <- data.frame(matrix(nrow = time_max, ncol = total_clones))

 names(evolution_clones) <- names(x)
 
for (i in 1:time_max) {
y <-  table(clones[which(clones[,1]==i),2])
evolution_clones[i,match(names(y),names(evolution_clones))] <- y  
}

evolution_clones[is.na(evolution_clones)] <- 0
 

# to plot all dependeces 

# Make a large number of colors

library("RColorBrewer")
c <- rownames(brewer.pal.info)
c <- c[1:9]
jColor <- data.frame(number = 1:11,color = I(brewer.pal(11, name = c[1])))
for (j in 2:9) {
  jColor1 <- data.frame(number = 1:11,color = I(brewer.pal(11, name = c[j])))
  jColor  <- rbind(jColor,jColor1)
}
jColor$number <- 1:99

g_range_y <- range(1, max(evolution_clones))
# brewer.pal(9,name = "Spectral")[2]

plot(1:time_max,evolution_clones[,1],type = "l",col = jColor$color[1],cex.lab=1.4,lwd=1.7,xlab = "Generation number",
     ylab = "Number of cells in each clone",ylim=g_range_y) #, log = "y")

for (i in 2:total_clones) {
 lines(1:time_max,evolution_clones[,i],col = jColor$color[i],lwd=1.7)
}


# the clones at the last time step
cl <- clones[which(clones[,1]==time_max),]

# Most popular clone
barplot(table(cl[,2]),xlab = "Name (unique number) of clone", ylab = "Number of clone's cells", space=0.7, col = "green") #, log = "y")

# Most popular clone (Drivers and Passengers)
barplot(table(cl[,4]),xlab = "Name (unique number) of clone: Drivers + Passengers", ylab = "Number of clone's cells", space=0.7, col = "green") #, log = "y")




ineq_clones <- matrix(0,nrow = time_max,ncol = 2)

# Inequality measure 
for (k in 1:time_max) {
  cl <- clones[which(clones[,1]==k),2]
ineq_clones[k,1] <- ineq(cl,type = "Gini")

cl2 <- clones[which(clones[,1]==k),4]
ineq_clones[k,2] <- ineq(cl2,type = "Gini")
}

g_range_y <- range(0, max(ineq_clones[,2], ineq_clones[,1]))

 plot(1:time_max,ineq_clones[,1],type = "l", lwd=3, pch = 19, col = "blue", ylim = g_range_y, xlab = "Time step", ylab = "Inequlity coefficient")
lines(1:time_max,ineq_clones[,2],type = "l", lwd=3, pch = 19, col =  "red")


# g_range_x[1]/2+g_range_x[2]/2.5, 1.2*g_range_y[2]
legend(1, 1.2*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1,horiz = TRUE)


# the Normal number of cells versus the inequality

g_range_x <- range(0,max(env$N))

plot(data_avg$N[1:time_max],ineq_clones[1:time_max,1],type = "p", lwd=3, pch = 19, col = "blue", ylim = g_range_y, xlim = g_range_x, xlab = "Number of NORMAL cells", ylab = "Inequlity coefficient")
lines(data_avg$N[1:time_max],ineq_clones[1:time_max,2],type = "p", lwd=3, pch = 19, col =  "red")


# g_range_x[1]/2+g_range_x[2]/2.5, 1.2*g_range_y[2]
legend(1, 1.2*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       cex=1,col=c("blue","red"), pch = 19, horiz = TRUE)



# the METASTASIS  number of cells versus the inequality

g_range_x <- range(0,max(env$M))

plot(data_avg$M[1:time_max],ineq_clones[1:time_max,1],type = "p", lwd=3, pch = 19, col = "blue", ylim = g_range_y, xlim = g_range_x, xlab = "Number of METASTASIS cells", ylab = "Inequlity coefficient")
lines(data_avg$M[1:time_max],ineq_clones[1:time_max,2],type = "p", lwd=3, pch = 19, col =  "red")


# g_range_x[1]/2+g_range_x[2]/2.5, 1.2*g_range_y[2]
legend(1, 1.2*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       cex=1,col=c("blue","red"), pch = 19, horiz = TRUE)


# To calculate the function of VAF and to make the plot gene weights versus VAF (the variant allele frequency)

read_genes(genefile)

l <- length(data_last[,1])

VAF <- matrix(nrow = l,ncol = len)

# 21 is a number of column BEFORE the gene's names
for (j in 1:len) {
VAF[which(data_last[,(21+j)]==""),j] <- 0
VAF[which(!data_last[,(21+j)]==""),j] <- 1
}


VAF_func <- matrix(nrow = 2, ncol = len)

for (i in 1:len) {
  VAF_func[1,i] <- weight_genes[i]
  VAF_func[2,i] <- sum(VAF[,i]) / l
  
}


g_range_x <- range(0.02,max(VAF_func[1,]))
g_range_y <- range(0.02,max(VAF_func[2,]))

plot(VAF_func[1,],VAF_func[2,],type = "p", lwd=3, pch = 19, col = "blue", ylim = g_range_y, xlim = g_range_x, xlab = "Gene weights", ylab = "Variant allele frequency")

