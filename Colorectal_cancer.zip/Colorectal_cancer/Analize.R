# The code to analize the results of simulation

analize_data <- function(celloutfile) {
# Analising of results:
data_out <- read.csv(celloutfile, sep="\t")
data_out[is.na(data_out)] <- ""
# make a readible names
names(data_out)[5] <-  "c"
names(data_out)[6] <-  "d"
names(data_out)[7] <-  "i"
names(data_out)[8] <-  "im"
names(data_out)[9] <-  "a"
names(data_out)[10] <- "k"
names(data_out)[11] <- "E"
names(data_out)[13] <- "Nmax"
names(data_out)

# average data
data_avg <<- data_out[which(data_out$AvgOrIndx == "avg"),]

# data without averaging - flow data
data_flow <<- data_out[which(!data_out$AvgOrIndx == "avg"),]

# the data of the last time step 
time_max <<- max(data_flow$Time)
data_last <<- data_flow[which(data_flow$Time == time_max),]


# let draw graphics 
# Numbers of Metastasis and normal cells
g_range_y <- range(0, data_avg$N,data_flow$M)
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))
plot(data_avg$Time,data_avg$M,type = "l",cex.lab=1.4,lwd=2,xlab = "Generation number",
     ylab = "Number of cells",ylim=g_range_y,xlim = g_range_x,col = "red")
lines(data_avg$Time,data_avg$N,type = "l",col = "blue",lwd=2)
par(xpd=TRUE)

# g_range_x[1]/2+g_range_x[2]/2.5, 1.2*g_range_y[2]
legend(g_range_x[1], 1.2*g_range_y[2], c("Normal","Metastasis"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1,horiz = TRUE)

rl <-  readline(prompt="This is a plot for Normal and Metastasis Numbers of cells - Press Enter  ")


# Average values of probabilities
g_range_y <- range(0, data_avg[6:10])
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))

plot(data_avg$Time,data_avg$d,type = "l", ylim=g_range_y,xlim = g_range_x,cex.lab=1.4,
     xlab = "Generation number",ylab = "The average probabilities",col = "red",lwd = 2)

lines(data_avg$Time,data_avg$i,type = "l",col = "blue",lwd = 2)
lines(data_avg$Time,data_avg$im,type = "l",col = "green",lwd = 2)
lines(data_avg$Time,data_avg$a,type = "l",col = "orange",lwd = 2)
lines(data_avg$Time,data_avg$k,type = "l",col = "black",lwd = 2)
par(xpd=TRUE)
legend(g_range_x[1], 1.2*g_range_y[2], c("d","i","im","a","k"), cex=1,col=c("red","blue","green","orange","black"), lty = 1:1,lwd = 2,horiz = TRUE)

rl <-  readline(prompt="This is a plot for Average values of probabilities - Press Enter  ")

# The averaged values of Hallmarks 
g_range_y <- range(0, data_avg[15:19])
g_range_x <- range(min(data_avg$Time),max(data_flow$Time))

plot(data_avg$Time,data_avg$Hd,type = "l", ylim=g_range_y,xlim = g_range_x,cex.lab=1.4,
     xlab = "Generation number",ylab = "The averaged Hallmarks values",col = "red",lwd = 2)

lines(data_avg$Time,data_avg$Hi,type = "l",col = "blue",lwd = 2)
lines(data_avg$Time,data_avg$Him,type = "l",col = "green",lwd = 2)
lines(data_avg$Time,data_avg$Ha,type = "l",col = "orange",lwd = 2)
lines(data_avg$Time,data_avg$Hb,type = "l",col = "black",lwd = 2)
par(xpd=TRUE)
legend(g_range_x[1], 1.2*g_range_y[2], c("Hd","Hi","Him","Ha","Hb"), cex=1,col=c("red","blue","green","orange","black"), lty = 1:1,lwd = 2,horiz = TRUE)

rl <-  readline(prompt="This is a plot for Average values of Hallmarks - Press Enter  ")

rl <-  readline(prompt="This is function to save the order of gene dysfunction to the file `Order_of_dysfunction.txt`  - Press Enter to save and view")
# The order of gene dysfunction 

order_dysfunction <<- data.frame(data_last[,21:(21+length(onco$name))],stringsAsFactors = FALSE)
names(order_dysfunction) <<- c("ID",onco$name)
order_dysfunction[,1] <<- data_last$ID

for (i in 1:(length(onco$name)+1)) {
order_dysfunction[,i] <<- as.character(order_dysfunction[,i])
}
#str(order_dysfunction)
order_dysfunction$ID <<- as.character(order_dysfunction$ID)
#str(order_dysfunction)



# substr(x, regexpr(":",x)+1, ifelse(isTRUE(grep(",",x)>0),(regexpr(",",x)-1),nchar(x)))


for (k in 1:length(order_dysfunction[,1])) {

    for (i in 2:(length(onco$name)+1)) {

    x<- order_dysfunction[k,i]
    order_dysfunction[k,i] <<- substr(x, regexpr(":",x)+1, ifelse(isTRUE(grep(",",x)>0),(regexpr(",",x)-1),nchar(x)))
  }
}


for (i in 1:length(onco$name)+1) {
  order_dysfunction[,i] <<- as.integer(order_dysfunction[,i])
}

outfile <- 'Order_of_dysfunction.txt'
header <- c('Order of gene dysfunction: from first to last', 'Frequency or number of cells with same order')
write(header, outfile, append=FALSE, ncolumn=length(header), sep="\t")  

#for (i in 1:length(order_dysfunction[,1])) {
#  data <- c(order_dysfunction$ID[i],names(sort(order_dysfunction[i,2:(length(onco$name)+1)])))
#  write(data, outfile, append=TRUE, ncolumn=length(data), sep="\t")
#    }

#    write_order_of_dysfunction('Order_of_dysfunction.txt', env, cells, isFirst)



x <- array("",dim = length(order_dysfunction[,1]))

for (i in 1:length(order_dysfunction[,1])) {
  data <- c(names(sort(order_dysfunction[i,2:(length(onco$name)+1)])))
  x[i] <- paste(data,collapse = " ")
}  
  
print("The order of gene dysfunction for each cell in the file")

# find the unique orders of genes dysfunction
uniq_order <<- table(x)
uniq_order <<- sort(uniq_order,decreasing = TRUE)
print("Unique of order of genes dysfunction and it's frequency:")
for (i in 1:length(uniq_order)) {
print(c(names(uniq_order)[i],uniq_order[[i]]))
data <- c(names(uniq_order)[i],uniq_order[[i]])
write(data, outfile, append=TRUE, ncolumn=length(data), sep="\t")
}
}  # \ analize_data <- function {  
    
    
    

