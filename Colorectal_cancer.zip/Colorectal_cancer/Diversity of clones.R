# Diversity of clones



# The function is in the Analize.R file 
analize_data(celloutfile)

# time_max - number of time steps 

clones <- matrix(nrow = length(data_flow$Time), ncol = 4)
clones[,1] <- as.integer(as.character(data_flow$Time))
clones[,2] <- as.integer(as.character(data_flow$Clone.number))
clones[,3] <- as.integer(as.character(data_flow$Passengers.Clone.number))
clones[,4] <- as.integer(as.character(data_flow$Mix.Clone.number))
#ord_cl <- 10^(length(onco$name))

#for (i in 1:length(clones[,1])) {
#clones[i,4] <- as.numeric(as.character(data_flow$Clone.number[i])) * ord_cl  + as.numeric(as.character(data_flow$Passengers.Clone.number[i])) 
#}


diversity <- matrix(nrow = time_max, ncol = 2)

for (i in 1:time_max) {
diversity[i,1] <- length(table(clones[which(clones[,1]==i),2]))
# diversity[i,2] <- diversity[i,1] / (data_avg$N[i] + data_avg$M[i])
diversity[i,2] <- length(table(clones[which(clones[,1]==i),4]))
}  

g_range_y <- range(0, max(diversity[,2],diversity[,1]))
plot(1:time_max,diversity[,1],type = "l",col = "blue", lwd=2, ylim=g_range_y, xlab = "Time step", ylab = "Number of clones") # number of clones - diversity
lines(1:time_max,diversity[,2],type = "l",col = "red", lwd=2)
legend(1, 1.2*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1,horiz = TRUE)

# plot(1:time_max,diversity[,2],type = "l",col = "red", lwd=2,xlab = "Time step", ylab = "Normilized diversity") # normalized diversity



# Number of cells in each clone

x <- table(clones[,2]) # names of all clones - "numeric" name of clones

total_clones <- length(names(x)) # number of all clones

 evolution_clones <- data.frame(matrix(nrow = time_max, ncol = total_clones))

 names(evolution_clones) <- names(x)
 
for (i in 1:time_max) {
y <-  table(clones[which(clones[,1]==i),2])
evolution_clones[i,match(names(y),names(evolution_clones))] <- y  
}

evolution_clones[is.na(evolution_clones)] <- 0
 

# to plot all dependeces 

# Make a large number of colors

nm <- length(evolution_clones)

w <- (nm^(1/3)) %/% 1 +1

st <-  w^3 %/% nm

sq <- seq(0,1-1/w,1/w)

cr <- 1:nm

l <- 0
R <- 1:(w^3)
G <- R
B <- R

for (i in 1:w) {
  for (j in 1:w) {
    for (k in 1:w) {
      l <- l+1
      R[l] <- sq[i]
      G[l] <- sq[j]
      B[l] <- sq[k]
      
    } 
  }  
}

seq(1,w^3,st) # is consequence of each color to make a high diversity of colors
jColor <- data.frame(number = 1:length(seq(1,w^3,st)),color = rgb(R[seq(1,w^3,st)],G[seq(1,w^3,st)],B[seq(1,w^3,st)]))

g_range_y <- range(0, max(evolution_clones))
# brewer.pal(9,name = "Spectral")[2]
g_range_y <- range(0,15)

plot(1:time_max,evolution_clones[,1],type = "l",col = jColor$color[1],cex.lab=1.6,lwd=3,xlab = "Generation number",
     ylab = "Number of cells in each clone",ylim=g_range_y, cex.axis = 1.6)

for (i in 2:total_clones) {
 lines(1:time_max,evolution_clones[,i],col = jColor$color[i],lwd=3)
}


# the clones at the last time step
cl <- clones[which(clones[,1]==time_max),]

# Most popular clone
barplot(table(cl[,2]),xlab = "The ID of clone", ylab = "Number of cells in the clone", main = "FOR DRIVERS",
        cex.lab=1.6, cex.axis = 1.2, cex.name = 1.6, space=0.7, col = "green")

# Most popular clone (Drivers and Passengers)
barplot(table(cl[,4]),xlab = "The ID of clone", ylab = "Number of cells in the clone", main = "FOR DRIVERS AND PASSENGERS",
        cex.lab=1.6, cex.axis = 1.2, cex.name = 1.2, space=0.7, col = "green")




ineq_clones <- matrix(0,nrow = time_max,ncol = 2)

# Inequality measure 
for (k in 1:time_max) {
  cl <- clones[which(clones[,1]==k),2]
ineq_clones[k,1] <- ineq(cl,type = "Gini")

cl2 <- clones[which(clones[,1]==k),4]
ineq_clones[k,2] <- ineq(cl2,type = "Gini")
}

g_range_y <- range(0, 1) # max(ineq_clones[,2], ineq_clones[,1]))

 plot(1:time_max,ineq_clones[,1],type = "l", lwd=3, pch = 19, col = "blue", 
      ylim = g_range_y, xlab = "Time step", ylab = "Inequlity coefficient",
      cex.axis = 1.5, cex.lab = 1.5)
lines(1:time_max,ineq_clones[,2],type = "l", lwd=3, pch = 19, col =  "red")


# g_range_x[1]/2+g_range_x[2]/2.5, 1.2*g_range_y[2]
legend(1, 1.15*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       lwd=2,cex=1.2,col=c("blue","red"), lty = 1:1,horiz = TRUE)



plot(data_avg$N,ineq_clones[,1],type = "l", lwd=3, pch = 19, col = "blue", ylim = g_range_y, xlab = "Number of normal cells", ylab = "Inequlity coefficient")
points(data_avg$N,ineq_clones[,2],type = "l", lwd=3, pch = 19, col =  "red")
legend(1, 1.2*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1,horiz = TRUE)



plot(data_avg$M,ineq_clones[,1],type = "l", lwd=3, pch = 19, col = "blue", ylim = g_range_y, xlab = "Number of metastasis cells", ylab = "Inequlity coefficient")
points(data_avg$M,ineq_clones[,2],type = "l", lwd=3, pch = 19, col =  "red")
legend(1, 1.2*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1,horiz = TRUE)



plot(data_avg$M+data_avg$N,ineq_clones[,1],type = "l", lwd=3, pch = 19, col = "blue", ylim = g_range_y, xlab = "Number of all cells", ylab = "Inequlity coefficient")
points(data_avg$M+data_avg$N,ineq_clones[,2],type = "l", lwd=3, pch = 19, col =  "red")
legend(1, 1.2*g_range_y[2], c("Drivers","Drivers+Passengers"), 
       lwd=2,cex=1,col=c("blue","red"), lty = 1:1,horiz = TRUE)



